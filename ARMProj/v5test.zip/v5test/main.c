//#include <stdio.h>
#define GPBCON *(volatile unsigned int*)0x56000010
#define GPBDAT *(volatile unsigned int*)0x56000014
#define GPBUDP *(volatile unsigned int*)0x56000018
	
 int __main(void){

	GPBCON = 1 << 2;//set GPB1 output function
	GPBUDP = 2 << 2;//set udp
	GPBDAT &= ~(1 << 1);//set GPB1 output 0
	while(1){};
	return 0;
 }